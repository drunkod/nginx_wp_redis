<?php
/**
 *
 * Login
 *
 * @package wpmll
 * @subpackage views
 * @since WP Magic Link Login 1.0
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<div id="wpmll-login-wrapper">
	<?php if ( isset( $_GET['wpmll_error'] ) ) : ?>
		<div class="wpmll-login-message error-message">
			<?php echo esc_html( $_GET['wpmll_error'] ); ?>
		</div>
	<?php endif; ?>
	<?php if ( isset( $_GET['wpmll_success'] ) ) : ?>
		<div class="wpmll-login-message">
			<?php echo esc_html( $_GET['wpmll_success'] ); ?>
		</div>
	<?php endif; ?>
	<div id="wpmll-login">
		<div class="wpmll-login-heading">
			<?php if ( !empty( $attr['heading'] ) ) : ?>
				<h3><?php echo esc_html( $attr['heading'] ); ?></h3>
			<?php endif; ?>
			<?php if ( !empty( $attr['description'] ) ) : ?>
				<p><?php echo esc_html( $attr['description'] ); ?></p>
			<?php endif; ?>
		</div>
		<form method="post" action="<?php echo esc_url( isset( $current_url ) ? add_query_arg( 'redirect_to', $current_url ) : '' ) ?>">
			<div class="pxl-row">
				<label><?php esc_html_e( 'Email address', 'wp-magic-link-login' ); ?></label>
				<input type="email" name="wpmll_email" value="" placeholder="<?php esc_attr_e( 'Enter your email address...', 'wp-magic-link-login' ); ?>" />
			</div>
			<div class="pxl-row-full">
				<input type="hidden" name="wpmll_action" value="send_magic" />
				<button type="submit" class="button-primary" name="wpmll_submit"><?php echo esc_attr( $attr['login-button-text'] ); ?></button>
			</div>
		</form>
	</div>
</div>
