<?php
/**
 *
 * Backend view
 *
 * @package wpmll
 * @subpackage _views
 * @since WP Magic Link Login 1.0
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>

<div class="wpmll-backend-wrapper" id="wpmll-be-main">
	<div class="wpmll-hero">
		<div class="wpmll-hero-intro">
			<h1><?php esc_html_e( 'WP Magic Link Login', 'wp-magic-link-login' ); ?></h1>
			<p>
				<?php esc_html_e( 'Allow users to login and register without password. Send them login link via email. Secure and simple.', 'wp-magic-link-login' ); ?>
			</p>
		</div>
	</div>

	<div class="wpmll-content">
		<form action="" method="post">
			<div class="pxl-row">
				<label class="pxl-label"><?php esc_html_e( 'Magic Link Login functionality is:', 'wp-magic-link-login' ); ?></label>
				<div class="pxl-radio-group">
					<label>
						<input type="radio" name="wpmll_enabled" value="1" <?php echo esc_attr( 1 == $wpmll['wpmll_enabled'] ? 'checked' : '' ); ?> />
						<span><?php esc_html_e( 'Enabled', 'wp-magic-link-login' ); ?></span>
					</label>
					<label>
						<input type="radio" name="wpmll_enabled" value="0" <?php echo esc_attr( 1 != $wpmll['wpmll_enabled'] ? 'checked' : '' ); ?> />
						<span><?php esc_html_e( 'Disabled', 'wp-magic-link-login' ); ?></span>
					</label>
				</div>
			</div>
			<div class="wpmll-enabled-form <?php echo 1 == $wpmll['wpmll_enabled'] ? 'is-enabled' : ''; ?>">
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Magic link form should:', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-radio-group">
						<label>
							<input type="radio" name="wpmll_form_type" value="1" <?php echo esc_attr( 1 == $wpmll['wpmll_form_type'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Replace the login form', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_form_type" value="0" <?php echo esc_attr( !in_array( $wpmll['wpmll_form_type'], array( 1, 2 ) ) ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Displayed below login form', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_form_type" value="2" <?php echo esc_attr( 2 == $wpmll['wpmll_form_type'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Displayed via shortcode only', 'wp-magic-link-login' ); ?></span>
						</label>
					</div>
				</div>
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Link validity (minutes)', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-slider-group">
						<input type="range" min="1" max="60" value="<?php echo esc_attr( $wpmll['wpmll_link_validity'] ); ?>" step="1" oninput="outputUpdate(value)" id="wpmll_link_validity_slider">
						<input type="number" name="wpmll_link_validity" value="<?php echo esc_attr( $wpmll['wpmll_link_validity'] ); ?>" id="wpmll_link_validity" />
					</div>
				</div>
				<?php if ( WPMLL_HAS_WOO ) : ?>
					<div class="pxl-row">
						<label class="pxl-label"><?php esc_html_e( 'Display Magic Link Form for WooCommerce pages?', 'wp-magic-link-login' ); ?></label>
						<div class="pxl-radio-group">
							<label>
								<input type="radio" name="wpmll_enabled_woo" value="1" <?php echo esc_attr( 1 == $wpmll['wpmll_enabled_woo'] ? 'checked' : '' ); ?> />
								<span><?php esc_html_e( 'Display', 'wp-magic-link-login' ); ?></span>
							</label>
							<label>
								<input type="radio" name="wpmll_enabled_woo" value="0" <?php echo esc_attr( 1 != $wpmll['wpmll_enabled_woo'] ? 'checked' : '' ); ?> />
								<span><?php esc_html_e( 'Do not display', 'wp-magic-link-login' ); ?></span>
							</label>
						</div>
					</div>
				<?php endif; ?>
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'User should login from the same IP that requested Magic Link?', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-radio-group">
						<label>
							<input type="radio" name="wpmll_same_ip" value="1" <?php echo esc_attr( 1 == $wpmll['wpmll_same_ip'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Yes', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_same_ip" value="0" <?php echo esc_attr( 1 != $wpmll['wpmll_same_ip'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'No', 'wp-magic-link-login' ); ?></span>
						</label>
					</div>
				</div>
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Alloweded users to login', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-radio-group">
						<label>
							<input type="radio" name="wpmll_allow_guests" value="0" <?php echo esc_attr( 1 != $wpmll['wpmll_allow_guests'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Only registered users', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_allow_guests" value="1" <?php echo esc_attr( 1 == $wpmll['wpmll_allow_guests'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'All users', 'wp-magic-link-login' ); ?></span>
						</label>
					</div>
				</div>

				<!-- Roles -->
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Assign role for new users', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-radio-group">
						<select name="wpmll_default_role">
							<?php wp_dropdown_roles( $wpmll['wpmll_default_role'] ); ?>
						</select>
					</div>
				</div>

                <div class="pxl-row">
                    <label class="pxl-label"><?php esc_html_e( 'Login Link Path', 'wp-magic-link-login' ); ?></label>
                    <em><?php esc_html_e( 'If you want to display custom login page, use the input below to set the path. For example /login-page. Leave empty to display the default page', 'wp-magic-link-login' );
                    ?></em><br>
                    <input type="text" name="wpmll_login_path" value="<?php echo esc_attr( !empty($wpmll['wpmll_login_path'])
                   ? $wpmll['wpmll_login_path'] : '' ); ?>" placeholder="<?php esc_attr_e( 'Enter the login path', 'wp-magic-link-login' )
                    ?>" />
                </div>

				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'On successful login, redirect user to:', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-radio-group">
						<label>
							<input type="radio" name="wpmll_redirect_to" value="profile" <?php echo esc_attr( 'profile' == $wpmll['wpmll_redirect_to'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Profile page', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_redirect_to" value="url" <?php echo esc_attr( 'url' == $wpmll['wpmll_redirect_to'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Custom url', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_redirect_to" value="page" <?php echo esc_attr( 'page' == $wpmll['wpmll_redirect_to'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Page', 'wp-magic-link-login' ); ?></span>
						</label>
					</div>
					<em><?php esc_html_e( 'Important: When requesting the Magic Link, if the url contains parameter redirect_to, it will override the redirect settings made above', 'wp-magic-link-login' ); ?></em>
				</div>
				<div class="pxl-row" id="pxl-redirect-url">
					<label class="pxl-label"><?php esc_html_e( 'Redirect to this url:', 'wp-magic-link-login' ); ?></label>
					<input type="url" name="wpmll_redirect_url" value="<?php echo esc_attr( $wpmll['wpmll_redirect_url'] ); ?>" />
				</div>
				<div class="pxl-row" id="pxl-redirect-page">
					<label class="pxl-label"><?php esc_html_e( 'Redirect to this page:', 'wp-magic-link-login' ); ?></label>
					<?php
					$args = array(
						'depth'                 => 0,
						'child_of'              => 0,
						'selected'              => ( isset( $wpmll['wpmll_redirect_page_id'] ) && 0 < $wpmll['wpmll_redirect_page_id'] ) ? $wpmll['wpmll_redirect_page_id'] : 0,
						'echo'                  => 1,
						'name'                  => 'wpmll_redirect_page_id',
						'id'                    => null,
						'class'                 => null,
						'show_option_none'      => null,
						'show_option_no_change' => null,
						'option_none_value'     => null,
					);
					wp_dropdown_pages( $args );
					?>
				</div>
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Allowed domains to login', 'wp-magic-link-login' ); ?></label>
					<div class="pxl-radio-group">
						<label>
							<input type="radio" name="wpmll_allowed_domains" value="all" <?php echo esc_attr( 'all' == $wpmll['wpmll_allowed_domains'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'All', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_allowed_domains" value="custom" <?php echo esc_attr( 'custom' == $wpmll['wpmll_allowed_domains'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Only specific domains', 'wp-magic-link-login' ); ?></span>
						</label>
						<label>
							<input type="radio" name="wpmll_allowed_domains" value="emails" <?php echo esc_attr( 'emails' == $wpmll['wpmll_allowed_domains'] ? 'checked' : '' ); ?> />
							<span><?php esc_html_e( 'Only specific emails', 'wp-magic-link-login' ); ?></span>
						</label>
					</div>
				</div>

				<div class="pxl-row" id="wpmll-allowed-domains">
					<label class="pxl-label"><?php esc_html_e( 'Allowed domains', 'wp-magic-link-login' ); ?></label>
					<div class="wpmll-allowed-domains-list">
						<?php if ( ! empty( $wpmll['wpmll_allowed_domains_list'] ) ) : ?>
							<?php foreach ( $wpmll['wpmll_allowed_domains_list'] as $key => $value ) : ?>
								<div class="wpmll-allowed-domains-list-item">
									@<input type="text" name="wpmll_allowed_domains_list[]" value="<?php echo esc_attr( $value ); ?>" />
									<a href="#" class="wpmll-delete-allowed-domain"><?php esc_html_e( 'Remove', 'wp-magic-link-login' ); ?></a>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
						<div class="wpmll-allowed-domains-list-item">
							@<input type="text" name="wpmll_allowed_domains_list[]" />
							<a href="#" class="wpmll-delete-allowed-domain"><?php esc_html_e( 'Remove', 'wp-magic-link-login' ); ?></a>
						</div>
					</div>
					<a href="#" class="wpmll-add-allowed-domain button-secondary"><?php esc_html_e( 'Add New Entry', 'wp-magic-link-login' ); ?></a>
				</div>

				<div class="pxl-row" id="wpmll-allowed-emails">
					<label class="pxl-label"><?php esc_html_e( 'Allowed emails', 'wp-magic-link-login' ); ?></label>
					<div class="wpmll-allowed-emails-list">
						<?php if ( ! empty( $wpmll['wpmll_allowed_emails_list'] ) ) : ?>
							<?php foreach ( $wpmll['wpmll_allowed_emails_list'] as $key => $value ) : ?>
								<div class="wpmll-allowed-emails-list-item">
									<input type="email" name="wpmll_allowed_emails_list[]" value="<?php echo esc_attr( $value ); ?>" />
									<a href="#" class="wpmll-delete-allowed-email"><?php esc_html_e( 'Remove', 'wp-magic-link-login' ); ?></a>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
						<div class="wpmll-allowed-emails-list-item">
							<input type="email" name="wpmll_allowed_emails_list[]" />
							<a href="#" class="wpmll-delete-allowed-email"><?php esc_html_e( 'Remove', 'wp-magic-link-login' ); ?></a>
						</div>
					</div>
					<a href="#" class="wpmll-add-allowed-email button-secondary"><?php esc_html_e( 'Add New Entry', 'wp-magic-link-login' ); ?></a>
				</div>

				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Email subject:', 'wp-magic-link-login' ); ?></label>
					<input type="text" name="wpmll_email_subject" value="<?php echo esc_attr( $wpmll['wpmll_email_subject'] ); ?>" />
				</div>
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Email sender (FROM):', 'wp-magic-link-login' ); ?></label>
					<input type="text" name="wpmll_email_sender" value="<?php echo esc_attr( $wpmll['wpmll_email_sender'] ); ?>" />
				</div>
				<div class="pxl-row">
					<label class="pxl-label"><?php esc_html_e( 'Email Content:', 'wp-magic-link-login' ); ?></label>
					<p><?php esc_html_e( "Use the shortcode {{WPMLL_LINK}} to display the magic link. If it's not used in email content, it will be appended automatically at the end of the email. For example, you can use it like this: ", 'wp-magic-link-login' ); ?></p>
					<code>&lt;a href="{{WPMLL_LINK}}"&gt;<?php esc_html_e( 'Click here to login', 'wp-magic-link-login' ); ?>&lt;/a&gt;</code>
					<?php wp_editor( $wpmll['wpmll_email_content'], 'wpmll_email_content' ); ?>
				</div>

                <br />

                <div class="pxl-row">
                    <label class="pxl-label"><?php esc_html_e( 'Enable firewall (brute force) protection', 'wp-magic-link-login' ); ?></label>
                    <div class="pxl-radio-group">
                        <label>
                            <input type="radio" name="firewall_active" value="0" <?php checked( $wpmll['firewall_active'], 0 ); ?> />
                            <span><?php esc_html_e( 'No', 'wp-magic-link-login' ); ?></span>
                        </label>
                        <label>
                            <input type="radio" name="firewall_active" value="1" <?php checked( $wpmll['firewall_active'], 1 ); ?> />
                            <span><?php esc_html_e( 'Yes', 'wp-magic-link-login' ); ?></span>
                        </label>
                    </div>
                </div>
                <div id="pxl-firewall-active">
                    <div class="pxl-row">
                        <em><?php esc_html_e( 'When IP is blocked, user will be able to access page but will not be able to see forms to request magic link login', 'wp-magic-link-login' ); ?></em>
                    </div>
                    <div class="pxl-row">
                        <label class="pxl-label"><?php esc_html_e( 'Block IP after how many login failures', 'wp-magic-link-login' ); ?></label>
                        <input type="tel" name="firewall_failures_count" value="<?php echo esc_attr( $wpmll['firewall_failures_count'] ); ?>" />
                    </div>
                    <div class="pxl-row">
                        <label class="pxl-label"><?php esc_html_e( 'Count failures over what time period (hours)', 'wp-magic-link-login' ); ?></label>
                        <input type="tel" name="firewall_failures_count_period" value="<?php echo esc_attr( $wpmll['firewall_failures_count_period'] ); ?>" />
                    </div>
                    <div class="pxl-row">
                        <label class="pxl-label"><?php esc_html_e( 'Amount of time a user is locked out (hours)', 'wp-magic-link-login' ); ?></label>
                        <input type="tel" name="firewall_ban_period" value="<?php echo esc_attr( $wpmll['firewall_ban_period'] ); ?>" />
                    </div>
                </div>

				<br />
				<div class="pxl-row">
					<label>
						<?php esc_html_e( 'Need to display the form with a shortcode?', 'wp-frontend-blocks' ); ?>
						<?php esc_html_e( 'Use the following shortcode:', 'wp-frontend-blocks' ); ?>
						<input type="text" value="[wpmll_form]" />
					</label>
				</div>
			</div>

			<div class="pxl-row">
				<input type="hidden" name="wpmll-action" value="save" />
				<?php wp_nonce_field( 'wpmll_nonce', 'wpmll_nonce' ); ?>
				<input type="submit" class="button-primary" value="<?php esc_attr_e( 'Save', 'wp-magic-link-login' ); ?>" />
			</div>
		</form>
	</div>
</div>
