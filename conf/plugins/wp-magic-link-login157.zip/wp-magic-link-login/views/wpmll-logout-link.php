<?php
/**
 *
 * Login
 *
 * @package wpmll
 * @subpackage views
 * @since WP Magic Link Login 1.0
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
?>
<a href="<?php echo esc_url( wp_logout_url() ); ?>"><?php echo esc_html( $attr['logout-link-text'] ); ?></a>
