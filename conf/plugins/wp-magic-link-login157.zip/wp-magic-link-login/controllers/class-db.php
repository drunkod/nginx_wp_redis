<?php
/**
 * DB controller
 *
 * @package wpmll
 * @subpackage controllers
 * @since WP Magic Link Login 1.0
 */

namespace Wpmll\Controllers;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Class DB Controller
 *
 * @category Controller
 * @package wpmll
 * @author  IV | PIXOLETTE
 * @license  https://pixolette.com
 * @link     https://pixolette.com
 */
class WpmllDb {

	public $wpmll_db_version;
	protected $table_name;
	protected $charset_collate;
    protected $table_name_firewall;

	/**
	 * Function to be called on class init
	 */
    public function __construct() {
		global $wpdb;

		$this->wpmll_db_version = '1.5.7';
		$this->charset_collate  = $wpdb->get_charset_collate();
		// table to store data
		$this->table_name = $wpdb->base_prefix . 'wpmll_magic_links';
		$this->table_name_firewall = $wpdb->base_prefix . 'wpmll_magic_link_firewall';
	}

	/**
	 * Function to create tables on plugin install
	 */
    public function create_table_on_install() {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// action types:
		// 0: allow non registered user to login
		// 1: allow only registered users to login
		$sql_templates = "CREATE TABLE $this->table_name (
			id int NOT NULL AUTO_INCREMENT,
			site_id int NULL,
			timestamp int NOT NULL,
			expire_timestamp int NOT NULL,
			user_ip text NOT NULL,
			user_key text NOT NULL,
			user_email text NOT NULL,
			action_type int DEFAULT 0 NULL,
			redirect_to text NULL,
			status int DEFAULT 0 NULL,
			activated_timestamp int NULL,
			PRIMARY KEY (id)
		) $this->charset_collate;";

		dbDelta( $sql_templates );

		$firewall_table_sql = "CREATE TABLE $this->table_name_firewall (
			id bigint NOT NULL AUTO_INCREMENT,
			site_id bigint NULL,
			timestamp bigint NOT NULL,
			expire_timestamp bigint NOT NULL,
			user_ip varchar(100) NOT NULL,
			url text NULL,
			PRIMARY KEY (id),
			INDEX `user_ip_index` (user_ip)
		) $this->charset_collate;";

        dbDelta( $firewall_table_sql );

        update_option( 'wpmll_db_version', $this->wpmll_db_version );
	}

    /**
     * Function to create entry
     *
     * @param mixed $data .
     *
     * @return int
     */
	public function create_entry( $data ) {
		global $wpdb;
		$res = $wpdb->insert( $this->table_name, $data );

		return $wpdb->insert_id;
	}

    /**
     * Function to update entry
     *
     * @param mixed $data .
     * @param int $id .
     *
     * @return bool|int
     */
    public function update_entry( $data, $id ) {
		global $wpdb;

		return $wpdb->update( $this->table_name, $data, array( 'id' => (int) $id ) );
	}

    /**
     * Function to delete entry
     *
     * @param int $id .
     *
     * @return bool|int
     */
    public function delete_entry( $id ) {
		global $wpdb;

		return $wpdb->delete( $this->table_name, array( 'id' => (int) $id ) );
	}

    /**
     * Function to get row entry
     *
     * @param int $id .
     *
     * @return array|object|void|null
     */
    public function get_entry_by_id( $id ) {
		global $wpdb;
		$sql = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE id = %d", (int) $id);

		return $wpdb->get_row( $sql, ARRAY_A );
	}

    /**
     * Function to get row entry
     *
     * @param $hash
     *
     * @return array|object|void|null
     */
    public function get_entry_by_hash( $hash ) {
		global $wpdb;
		$sql = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE user_key = %s AND status = 1 AND activated_timestamp IS NULL", $hash );

		return $wpdb->get_row( $sql, ARRAY_A );
	}

    /**
     * Function to get all entries
     *
     * @param int $page_nr .
     * @param int $per_page .
     *
     * @return array|object|null
     */
    public function get_entries( $page_nr = 1, $per_page = 10 ) {
		global $wpdb;
		$site_id = get_current_blog_id();
		$offset  = ( $page_nr - 1 ) * $per_page;
		$sql     = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE site_id = %d ORDER BY id DESC LIMIT %d, %d", $site_id, $offset, $per_page );

		return $wpdb->get_results( $sql, ARRAY_A );
	}

    /**
     * Function to get all entries
     *
     * @param int $page_nr .
     * @param int $per_page .
     *
     * @return array|object|null
     */
    public function get_entries_for_reports( $page_nr = 1, $per_page = 10 ) {
		global $wpdb;
		$site_id = get_current_blog_id();
		$offset  = ( $page_nr - 1 ) * $per_page;
		$sql     = $wpdb->prepare( "SELECT timestamp, expire_timestamp, user_ip, user_email, status, activated_timestamp FROM $this->table_name WHERE site_id = %d ORDER BY id DESC LIMIT %d, %d", $site_id, $offset, $per_page );

		return $wpdb->get_results( $sql, ARRAY_A );
	}

    /**
     * Function to get all entries
     *
     * @return array|object|void|null
     */
    public function get_total_entries_for_reports() {
		global $wpdb;
		$site_id = get_current_blog_id();
		$sql     = $wpdb->prepare( "SELECT count(id) as total_entries FROM $this->table_name WHERE status = %d AND site_id = %d", 1, $site_id );

		return $wpdb->get_row( $sql, ARRAY_A );
	}

    /**
     * Function to create entry
     *
     * @param mixed $data .
     *
     * @return int
     */
    public function firewall_create_entry( $data ) {
        global $wpdb;
        $wpdb->insert( $this->table_name_firewall, $data );

        return $wpdb->insert_id;
    }

    /**
     * Function to update entry
     *
     * @param mixed $data .
     * @param int $id .
     *
     * @return bool|int
     */
    public function firewall_update_entry( $data, $id ) {
        global $wpdb;

        return $wpdb->update( $this->table_name_firewall, $data, array( 'id' => (int) $id ) );
    }

    /**
     * Function to delete entry
     *
     * @param int $id .
     *
     * @return bool|int
     */
    public function firewall_delete_entry( $id ) {
        global $wpdb;

        return $wpdb->delete( $this->table_name_firewall, array( 'id' => (int) $id ) );
    }

    /**
     * Function to get row entry
     *
     * @param int $id .
     *
     * @return array|object|void|null
     */
    public function firewall_get_entry_by_id( $id ) {
        global $wpdb;
        $sql = $wpdb->prepare( "SELECT * FROM $this->table_name_firewall WHERE id = %d", (int) $id);

        return $wpdb->get_row( $sql, ARRAY_A );
    }

    /**
     * Function to get row entry
     *
     * @param int $id .
     *
     * @return array|object|void|null
     */
    public function firewall_get_entries_by_ip( $ip, $timestamp, $count = 5 ) {
        global $wpdb;
        $sql = $wpdb->prepare( "SELECT * FROM $this->table_name_firewall WHERE user_ip = %s AND expire_timestamp > %d ORDER BY expire_timestamp DESC LIMIT %d, %d",
            $ip, (int) $timestamp, 0, $count );

        return $wpdb->get_results( $sql, ARRAY_A );
    }

}
