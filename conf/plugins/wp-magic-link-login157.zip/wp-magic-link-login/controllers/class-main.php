<?php
/**
 * Main controller
 *
 * @package wpmll
 * @subpackage controllers
 * @since WP Magic Link Login 1.1
 */

namespace Wpmll\Controllers;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

require_once WPMLL_PLUGIN_PATH . 'controllers/class-magic.php';
require_once WPMLL_PLUGIN_PATH . 'controllers/class-db.php';
require_once WPMLL_PLUGIN_PATH . 'controllers/class-firewall.php';

use Wpmll\Controllers\Firewall;
use Wpmll\Controllers\WpmllMagic;
use Wpmll\Controllers\WpmllDb;

/**
 * Class Main Controller
 *
 * @category Controller
 * @package wpmll
 * @author  IV | PIXOLETTE
 * @license  https://pixolette.com
 * @link     https://pixolette.com
 */
class WpmllMain {

	protected $site_option_slug = 'wpmll_site_options_value';
	protected $wpmll = array(
		'wpmll_enabled' => 0,
		'wpmll_form_type' => 0,
		'wpmll_enabled_woo' => 0,
		'wpmll_link_validity' => 3,
		'wpmll_same_ip' => 1,
		'wpmll_allow_guests' => 0,
		'wpmll_default_role' => 'subscriber',
		'wpmll_display_login_form' => 0,
		'wpmll_redirect_to' => 'profile',
		'wpmll_redirect_url' => false,
		'wpmll_redirect_page_id' => false,
		'wpmll_allowed_domains' => 'all',
		'wpmll_allowed_domains_list' => array(),
		'wpmll_allowed_emails_list' => array(),
		'wpmll_email_sender' => false,
		'wpmll_email_subject' => false,
		'wpmll_email_content' => false,
		'wpmll_login_path' => '',
		'firewall_active' => '0',
		'firewall_failures_count' => 5,
		'firewall_failures_count_period' => 24,
		'firewall_ban_period' => 24,
	);

    public function admin_enqueue( $hook ) {
		if ( in_array( $hook, array( 'toplevel_page_wpmll', 'magic-link_page_wpmll-reports' ) ) && is_admin() ) {
			wp_enqueue_style( 'wpmll-be-style', WPMLL_PLUGIN_URL . 'assets/css/wpmll-be-style.css', array(), '1.0' );

			wp_enqueue_script( 'wpmll-wpadmin-scripts', WPMLL_PLUGIN_URL . 'assets/js/be-scripts.js', array( 'jquery' ), '1.0', true );
		}
	}

    public function wpmll_enqueue_scripts( $hook ) {
		wp_register_style( 'wpmll-magic-form', WPMLL_PLUGIN_URL . 'assets/css/wpmll-form.css', array(), '1.0' );
	}

    public function wpmll_enqueue_magic_form_scripts( $hook ) {
		wp_register_style( 'wpmll-magic-form', WPMLL_PLUGIN_URL . 'assets/css/wpmll-form.css', array(), '1.0' );
		wp_enqueue_style( 'wpmll-magic-form' );
	}

    public function login_page_init() {
		$wpmll = $this->get_settings();
		if ( isset( $_GET['wpmll_magic'] ) ) {
            $is_ip_banned = Firewall::is_ip_banned();
            if ( $is_ip_banned ) {
                return true;
            }

			$magic = new WpmllMagic();
			$current_ip = false;
			if ( 1 === (int) $wpmll['wpmll_same_ip'] ) {
				$current_ip = Firewall::get_ip();
			}
			$update_status = $magic->check_magic_link_entry_and_invalidate(
			    $wpmll,
                sanitize_text_field( $_GET['wpmll_magic'] ),
                $current_ip
            );

			if ( $wpmll && $update_status['success'] ) {
				// if only registered users allowed
				if ( 1 !== (int) $wpmll['wpmll_allow_guests'] ) {
					$user = get_user_by( 'email', $update_status['email'] );
					if ( ! is_wp_error( $user ) && $user ) {
						if ( trim( $update_status['redirect_to'] ) ) {
							$redirect = $update_status['redirect_to'];
						} else {
							switch ( $wpmll['wpmll_redirect_to'] ) {
								case 'url':
									$redirect = $wpmll['wpmll_redirect_url'];
									break;
								case 'page':
									$redirect = get_permalink( $wpmll['wpmll_redirect_page_id'] );
									break;
								default:
									$redirect = admin_url( 'profile.php' );
									break;
							}
						}

						wp_clear_auth_cookie();
						wp_set_current_user ( $user->ID );
						wp_set_auth_cookie  ( $user->ID );
						do_action( 'wp_login', $update_status['email'], $user );

						if ( class_exists( 'SimpleWpMembership' ) ) {
							$swm_controller = new \SimpleWpMembership();
							$swm_controller->set_current_user_handler();
						}

						wp_redirect( $redirect );
						echo json_encode( array( 'error_code' => 0 ) );
						exit();
					} else {
						echo json_encode( array( 'error_code' => 1 ) );
						exit();
					}
				} else {
					$user = get_user_by( 'email', $update_status['email'] );
					if ( ! $user ) {
						$user_data = array(
							'user_login' => $update_status['email'],
							'user_email' => $update_status['email'],
							'user_pass'  => wp_generate_password(),
							'first_name' => $update_status['email'],
							'nickname'   => $update_status['email'],
							'role'       => $wpmll['wpmll_default_role'],
						);
						$user_id = wp_insert_user( $user_data );
						$user = get_user_by( 'ID', $user_id );
					} else {
						$user_id = $user->ID;
					}

					if ( ! is_wp_error( $user_id ) ) {
						switch ( $wpmll['wpmll_redirect_to'] ) {
							case 'url':
								$redirect = $wpmll['wpmll_redirect_url'];
								break;
							case 'page':
								$redirect = get_permalink( $wpmll['wpmll_redirect_page_id'] );
								break;
							default:
								$redirect = admin_url( 'profile.php' );
								break;
						}

						wp_clear_auth_cookie();
						wp_set_current_user ( $user_id );
						wp_set_auth_cookie  ( $user_id );
						do_action( 'wp_login', $update_status['email'], $user );

						wp_redirect( $redirect );
						echo json_encode( array( 'error_code' => 0 ) );
						exit();
					} else {
						echo json_encode( array( 'error_code' => 3 ) );
						exit();
					}
				}
			} else {
			    if ( 1 === (int) $wpmll['firewall_active'] ) {
			        Firewall::ban_ip(
			            Firewall::get_ip(),
                        $wpmll['firewall_failures_count_period'],
                        Firewall::get_current_url()
                    );
                }
				wp_redirect( add_query_arg( 'wpmll_error', urlencode( $update_status['message'] ), remove_query_arg( 'wpmll_magic' ) ) );
				exit;
			}
		}
	}

    public function wpmll_display_magic_form_header() {
        // Check if Firewall is ON and IP is banned.
        $is_ip_banned = Firewall::is_ip_banned();
        if ( $is_ip_banned ) {
            return '';
        }

		$wpmll = $this->get_settings();
		if ( isset( $wpmll['wpmll_enabled'] ) && 1 == $wpmll['wpmll_enabled'] ) {
			if ( isset( $wpmll['wpmll_form_type'] ) && 1 == $wpmll['wpmll_form_type'] ) {
				$this->wpmll_display_magic_form_action();
				include WPMLL_PLUGIN_PATH . 'views/wpmll-form.php';
				if ( ! isset( $_GET['show_login_form'] ) || isset( $_GET['show_login_form'] ) && 1 != $_GET['show_login_form'] ) {
					exit();
				}
			}
		}
	}

    public function wpmll_display_magic_form_footer() {
        // Check if Firewall is ON and IP is banned.
        $is_ip_banned = Firewall::is_ip_banned();
        if ( $is_ip_banned ) {
            return '';
        }

		$wpmll = $this->get_settings();
		if ( isset( $wpmll['wpmll_enabled'] ) && 1 == $wpmll['wpmll_enabled'] ) {
			if ( isset( $wpmll['wpmll_form_type'] ) && !in_array( $wpmll['wpmll_form_type'], array( 1,2 ) ) ) {
				$this->wpmll_display_magic_form_action();
				include WPMLL_PLUGIN_PATH . 'views/wpmll-form.php';
			}
		}
	}

    public function wpmll_display_magic_form_footer_woo() {
        // Check if Firewall is ON and IP is banned.
        $is_ip_banned = Firewall::is_ip_banned();
        if ( $is_ip_banned ) {
            return '';
        }

		$wpmll = $this->get_settings();
		if ( isset( $wpmll['wpmll_enabled'] ) && 1 == $wpmll['wpmll_enabled'] && isset( $wpmll['wpmll_enabled_woo'] ) && 1 == $wpmll['wpmll_enabled_woo'] ) {
			wp_enqueue_style( 'wpmll-magic-form', WPMLL_PLUGIN_URL . 'assets/css/wpmll-form.css', array(), '1.0' );
			$this->wpmll_display_magic_form_action();
			include WPMLL_PLUGIN_PATH . 'views/wpmll-form.php';
		}
	}

    public function wpmll_display_magic_form_checkout_woo() {
        // Check if Firewall is ON and IP is banned.
        $is_ip_banned = Firewall::is_ip_banned();
        if ( $is_ip_banned ) {
            return '';
        }

		if ( is_user_logged_in() || 'no' === get_option( 'woocommerce_enable_checkout_login_reminder' ) ) {
			return;
		}
		$wpmll = $this->get_settings();
		if ( isset( $wpmll['wpmll_enabled'] ) && 1 == $wpmll['wpmll_enabled'] && isset( $wpmll['wpmll_enabled_woo'] ) && 1 == $wpmll['wpmll_enabled_woo'] ) {
			wp_enqueue_style( 'wpmll-magic-form', WPMLL_PLUGIN_URL . 'assets/css/wpmll-form.css', array(), '1.0' );
			$this->wpmll_display_magic_form_action();
			include WPMLL_PLUGIN_PATH . 'views/wpmll-form.php';
		}
	}

    public function wpmll_display_magic_form_action() {
		if ( isset( $_POST['wpmll_action'] ) && 'send_magic' == $_POST['wpmll_action'] ) {
			if ( isset( $_POST['wpmll_email'] ) && trim( $_POST['wpmll_email'] ) ) {
				$email = sanitize_email( wp_unslash( $_POST['wpmll_email'] ) );
				if ( ! is_email( $email ) ) {
					wp_redirect( add_query_arg( 'wpmll_error', urlencode( esc_html__( 'Please submit a valid email address', 'wp-magic-link-login' ) ), remove_query_arg( 'wpmll_success' ) ) );
				}

				$redirect_to = false;
				if ( isset( $_GET['redirect_to'] ) ) {
					$redirect_to = wp_sanitize_redirect( $_GET['redirect_to'] );
				}

				$magic = new WpmllMagic();
				if ( ! defined( 'DOING_WPMLL' ) ) {
					// prevent sending multiple emails if there are multiple shortcodes on the same page
					define( 'DOING_WPMLL', true );
					$current_ip = Firewall::get_ip();
					$response = $magic->create_magic_entry( $email, $current_ip, $redirect_to );
					if ( $response['success'] ) {
						$url = add_query_arg( 'wpmll_success', urlencode( $response['message'] ), remove_query_arg( 'wpmll_error' ) );
						wp_safe_redirect( $url );
					} else {
						wp_redirect( add_query_arg( 'wpmll_error', urlencode( $response['message'] ), remove_query_arg( 'wpmll_success' ) ) );
						exit;
					}
				}
			} else {
				wp_redirect( add_query_arg( 'wpmll_error', urlencode( esc_html__( 'Please submit a valid email address', 'wp-magic-link-login' ) ), remove_query_arg( 'wpmll_success' ) ) );
				exit;
			}
		}
	}


	/**
	 * Init plugin admin page
	 */
    public function admin_page_init() {
		add_menu_page( 'WP Magic Link Login', 'Magic Link', 'manage_options', 'wpmll', array( $this, 'init_backend' ), 'dashicons-admin-network' );
		add_submenu_page( 'wpmll', 'Magic Link Settings', 'Settings', 'manage_options', 'wpmll' );
		add_submenu_page( 'wpmll', 'Reports', 'Reports', 'manage_options', 'wpmll-reports', array( $this, 'init_reports_page' ) );
	}

    public function get_settings() {
		$wpmll = get_option( $this->site_option_slug );
		if ( ! $wpmll ) {
			return $this->wpmll;
		} else {
			if ( isset( $wpmll['wpmll_allowed_domains_list'] ) && ! is_array( $wpmll['wpmll_allowed_domains_list'] ) ) {
				$wpmll['wpmll_allowed_domains_list'] = json_decode( $wpmll['wpmll_allowed_domains_list'], true );
			} else if ( isset( $wpmll['wpmll_allowed_domains_list'] ) && empty( $wpmll['wpmll_allowed_domains_list'] ) ) {
				$wpmll['wpmll_allowed_domains_list'] = array();
			}
			if ( isset( $wpmll['wpmll_allowed_emails_list'] ) ) {
				$wpmll['wpmll_allowed_emails_list'] = json_decode( $wpmll['wpmll_allowed_emails_list'], true );
			} else {
				$wpmll['wpmll_allowed_emails_list'] = array();
			}
			if ( ! isset( $wpmll['wpmll_default_role'] ) ) {
				$wpmll['wpmll_default_role'] = 'subscriber';
			}
			$this->wpmll = wp_parse_args( $wpmll, $this->wpmll );

			return $this->wpmll;
		}

	}

    public function update_settings( $wpmll ) {
		update_option( $this->site_option_slug, $wpmll );
		$this->wpmll = $wpmll;
	}

    public function init_backend() {

		$magic = new WpmllMagic();

		if ( isset( $_POST['wpmll-action'] ) && 'save' == $_POST['wpmll-action'] ) {
			if ( ! isset( $_POST['wpmll_nonce'] ) || ! wp_verify_nonce( $_POST['wpmll_nonce'], 'wpmll_nonce' ) ) {
				print 'Invalid nonce.';
				exit;
			} else {
				$errors = array();
				if ( 1 > $_POST['wpmll_link_validity'] || 1440 < $_POST['wpmll_link_validity'] ) {
					$errors['wpmll_link_validity'] = esc_html__( 'Please set a value between 1 and 1440' );
				} else {
					$wpmll['wpmll_link_validity'] = sanitize_text_field( wp_unslash( $_POST['wpmll_link_validity'] ) );
				}
				$wpmll['wpmll_enabled'] = sanitize_text_field( wp_unslash( $_POST['wpmll_enabled'] ) );
				if ( WPMLL_HAS_WOO ) {
					$wpmll['wpmll_enabled_woo'] = sanitize_text_field( wp_unslash( $_POST['wpmll_enabled_woo'] ) );
				}
				$wpmll['wpmll_form_type'] = sanitize_text_field( wp_unslash( $_POST['wpmll_form_type'] ) );
				$wpmll['wpmll_same_ip'] = sanitize_text_field( wp_unslash( $_POST['wpmll_same_ip'] ) );
				$wpmll['wpmll_allow_guests'] = sanitize_text_field( wp_unslash( $_POST['wpmll_allow_guests'] ) );
				$wpmll['wpmll_default_role'] = sanitize_text_field( wp_unslash( $_POST['wpmll_default_role'] ) );
				$wpmll['wpmll_redirect_to'] = sanitize_text_field( wp_unslash( $_POST['wpmll_redirect_to'] ) );
				$wpmll['wpmll_login_path'] = sanitize_text_field( wp_unslash( $_POST['wpmll_login_path'] ) );

				switch ( $_POST['wpmll_redirect_to'] ) {
					case 'url':
						if ( ! trim( $_POST['wpmll_redirect_url'] ) ) {
							$errors['wpmll_redirect_url'] = esc_html__( 'You must submit a redirect url' );
						}
						break;
					case 'page':
						if ( ! $_POST['wpmll_redirect_page_id'] ) {
							$errors['wpmll_redirect_page_id'] = esc_html__( 'You must submit a redirect url' );
						}
						break;
				}
				$wpmll['wpmll_redirect_url'] = sanitize_text_field( wp_unslash( $_POST['wpmll_redirect_url'] ) );
				$wpmll['wpmll_redirect_page_id'] = sanitize_text_field( wp_unslash( $_POST['wpmll_redirect_page_id'] ) );

				$wpmll['wpmll_email_sender'] = $_POST['wpmll_email_sender'];
				$wpmll['wpmll_email_subject'] = sanitize_text_field( wp_unslash( $_POST['wpmll_email_subject'] ) );
				$wpmll['wpmll_email_content'] = wp_kses_post( stripslashes( $_POST['wpmll_email_content'] ) );

				$wpmll['wpmll_allowed_domains'] = sanitize_text_field( wp_unslash( $_POST['wpmll_allowed_domains'] ) );

				$_POST['wpmll_allowed_domains_list'] = array_filter( $_POST['wpmll_allowed_domains_list'], function( $value ) { return trim( $value ) !== ''; } );

				$wpmll['wpmll_allowed_domains_list'] = wp_json_encode( $_POST['wpmll_allowed_domains_list'] );
				if ( empty( $errors ) ) {
					$this->update_settings( $wpmll );

					$wpmll['wpmll_allowed_domains_list'] = json_decode( $wpmll['wpmll_allowed_domains_list'], true );
				}

				$_POST['wpmll_allowed_emails_list'] = array_filter( $_POST['wpmll_allowed_emails_list'], function( $value ) { return trim( $value ) !== ''; } );

				$wpmll['wpmll_allowed_emails_list'] = wp_json_encode( $_POST['wpmll_allowed_emails_list'] );

                $wpmll['firewall_active'] = sanitize_text_field( wp_unslash( $_POST['firewall_active'] ) );
                $wpmll['firewall_failures_count'] = sanitize_text_field( wp_unslash( $_POST['firewall_failures_count'] ) );
                $wpmll['firewall_failures_count_period'] = sanitize_text_field( wp_unslash( $_POST['firewall_failures_count_period'] ) );
                $wpmll['firewall_ban_period'] = sanitize_text_field( wp_unslash( $_POST['firewall_ban_period'] ) );

				if ( empty( $errors ) ) {
					$this->update_settings( $wpmll );

					$wpmll['wpmll_allowed_emails_list'] = json_decode( $wpmll['wpmll_allowed_emails_list'], true );
				}
			}
		} else {
			$wpmll = $this->get_settings();
			if ( ! isset( $wpmll['wpmll_enabled_woo'] ) ) {
				$wpmll['wpmll_enabled_woo'] = 0;
			}
		}

		include WPMLL_PLUGIN_PATH . 'views/be-main.php';
	}

    public function init_reports_page() {
		$wpmll = $this->get_settings();
		$db = new WpmllDb();
		$current_page = 1;
		if ( isset( $_GET['page_nr'] ) ) {
			$current_page = (int) $_GET['page_nr'];
		}
		$per_page = 25;
		$links_data = $db->get_entries_for_reports( $current_page, $per_page );
		$links_data_count = $db->get_total_entries_for_reports();
		$total_pages = 1;
		if ( $links_data_count && isset( $links_data_count['total_entries'] ) ) {
			$total_pages = ceil( $links_data_count['total_entries'] / $per_page );
		}

		include WPMLL_PLUGIN_PATH . 'views/be-reports.php';
	}

    public function wpmll_get_status_writing( $status ) {
		switch ( $status ) {
			case -1:
				return esc_html__( 'Activated', 'wp-magic-link-login' );
				break;
			case 1:
				return esc_html__( 'Valid', 'wp-magic-link-login' );
				break;
			default:
				return esc_html__( 'Invalid', 'wp-magic-link-login' );
				break;
		}
	}

    public function wpmll_gmt_to_local_timestamp( $gmt_timestamp ) {
		return get_date_from_gmt( date( 'Y-m-d H:i:s', $gmt_timestamp ), 'd M Y, H:i' );
	}

    public function wpmll_init() {
		add_shortcode( 'wpmll_form', array( $this, 'display_login_form_shortcode' ) );

		add_action( 'wpmll_generate_login_link', array( $this, 'wpmll_generate_login_link' ), 10, 2 );

		$wpmll = $this->get_settings();
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		if ( is_plugin_active( 'polylang/polylang.php' ) && function_exists( 'pll_register_string' ) ) {
			pll_register_string( 'Magic Link - Email Subject', $wpmll['wpmll_email_subject'], 'WP Magic Link Login Plugin' );
			pll_register_string( 'Magic Link - Email Content', $wpmll['wpmll_email_content'], 'WP Magic Link Login Plugin', true );
		}
		if ( is_plugin_active( 'polylang-pro/polylang.php' ) && function_exists( 'pll_register_string' ) ) {
			pll_register_string( 'Magic Link - Email Subject', $wpmll['wpmll_email_subject'], 'WP Magic Link Login Plugin' );
			pll_register_string( 'Magic Link - Email Content', $wpmll['wpmll_email_content'], 'WP Magic Link Login Plugin', true );
		}
	}

    public function display_login_form_shortcode( $attributes, $content = null ) {
		$attr = shortcode_atts( array(
			'redirect_to'  => '',
			'heading'  => esc_html__( 'Magic Link', 'wp-magic-link-login' ),
			'description'  => esc_html__( 'Login without password: send the one time unique login link to your email and login with 1 click', 'wp-magic-link-login' ),
			'login-button-text'  => esc_attr__( 'Send me the link', 'wp-magic-link-login' ),
			'logout-link-text'  => esc_attr__( 'Logout', 'wp-magic-link-login' ),
		), $attributes );
		if (is_user_logged_in()) {
			ob_start();
			include WPMLL_PLUGIN_PATH . 'views/wpmll-logout-link.php';
			return ob_get_clean();
		} else {
		    // Check if Firewall is ON and IP is banned.
            $is_ip_banned = Firewall::is_ip_banned();
            if ( $is_ip_banned ) {
                return '';
            }

			$wpmll = $this->get_settings();
			if ( 'current-page' == $attr['redirect_to'] ) {
				global $wp;
				$current_url = home_url( add_query_arg( array(), $wp->request ) );
			} elseif ( !empty( $attr['redirect_to'] ) ) {
				$current_url = esc_url_raw( $attr['redirect_to'] );
			}
			if ( isset( $wpmll['wpmll_enabled'] ) && 1 == $wpmll['wpmll_enabled'] ) {
				wp_enqueue_style( 'wpmll-magic-form' );
				$this->wpmll_display_magic_form_action();
				ob_start();
				include WPMLL_PLUGIN_PATH . 'views/wpmll-shortcode.php';
				return ob_get_clean();
			}
		}
	}

	/**
	 * Hook to generate magic link
	 */
	public function wpmll_generate_login_link( $email_address, $redirect_to = '' ) {
		$magic_settings = $this->get_settings();
		if ( 1 == $magic_settings['wpmll_enabled'] ) {
			if ( !empty( $email_address ) ) {
				if ( !is_array( $email_address ) ) {
					$email_addresses[] = $email_address;
				} else {
					$email_addresses = $email_address;
				}
				if ( !empty( $redirect_to ) ) {
					$redirect_to = wp_sanitize_redirect( $redirect_to );
				}
				$magic = new WpmllMagic();
				foreach ($email_addresses as $key => $email) {
					$response = $magic->create_magic_entry( $email, 'hook_wpmll_generate_login_link', $redirect_to );
					$success[] = $response['success'];
				}
			}
		}
	}
}
