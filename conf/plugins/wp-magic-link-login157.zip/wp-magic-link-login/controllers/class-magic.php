<?php
/**
 * Main controller
 *
 * @package wpmll
 * @subpackage controllers
 * @since WP Magic Link Login 1.0
 */

namespace Wpmll\Controllers;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

require_once WPMLL_PLUGIN_PATH . 'controllers/class-db.php';
require_once WPMLL_PLUGIN_PATH . 'controllers/class-main.php';
require_once WPMLL_PLUGIN_PATH . 'controllers/class-firewall.php';
use Wpmll\Controllers\WpmllDb;
use Wpmll\Controllers\Firewall;
use Wpmll\Controllers\WpmllMain as MainController;

/**
 * Class Magic Controller
 *
 * @category Controller
 * @package wpmll
 * @author  IV | PIXOLETTE
 * @license  https://pixolette.com
 * @link     https://pixolette.com
 */
class WpmllMagic {

	public function create_magic_entry( $email, $ip, $redirect_to = false ) {
		$mc = new MainController();
		$magic_settings = $mc->get_settings();

		// guests are allowed to login?
		if ( 1 != $magic_settings['wpmll_allow_guests'] ) {
			$user = get_user_by( 'email', $email );
			if ( ! $user || is_wp_error( $user ) ) {
                if ( 1 === (int) $magic_settings['firewall_active'] ) {
                    Firewall::ban_ip(
                        Firewall::get_ip(),
                        $magic_settings['firewall_failures_count_period'],
                        Firewall::get_current_url()
                    );
                }
				return array(
					'success' => false,
					'message' => esc_html__( 'Email address is not allowed.', 'wp-magic-link-login' ),
				);
				exit;
			}
		}

		// check the email in allowed list
		if ( 'custom' == $magic_settings['wpmll_allowed_domains'] && ! empty( $magic_settings['wpmll_allowed_domains_list'] ) ) {
			$matches = array_filter( $magic_settings['wpmll_allowed_domains_list'], function( $var ) use ( $email ) {
				$length = strlen( $var );
				return (substr($email, -$length) === $var);
			} );

			if ( empty( $matches ) ) {
				return array(
					'success' => false,
					'message' => esc_html__( 'Email addres is not allowed.', 'wp-magic-link-login' ),
				);
				exit;
			}
		}

		// check the email in allowed list
		if ( 'emails' == $magic_settings['wpmll_allowed_domains'] && ! empty( $magic_settings['wpmll_allowed_emails_list'] ) ) {
			$matches = array_filter( $magic_settings['wpmll_allowed_emails_list'], function( $var ) use ( $email ) {
				$length = strlen( $var );
				return (substr($email, -$length) === $var);
			} );

			if ( empty( $matches ) ) {
				return array(
					'success' => false,
					'message' => esc_html__( 'Email addres is not allowed.', 'wp-magic-link-login' ),
				);
				exit;
			}
		}

		$data = array(
			'site_id' => get_current_blog_id(),
			'timestamp' => time(),
			'expire_timestamp' => time() + 60 * $magic_settings['wpmll_link_validity'],
			'user_ip' => $ip,
			'user_key' => $this->generate_magic_hash(),
			'user_email' => $email,
			'redirect_to' => $redirect_to,
			'status' => 1,
		);
		$db = new WpmllDb();
		$inserted_id = $db->create_entry( $data );
		if ( $inserted_id > 0 ) {
		    if ( ! empty( $magic_settings['wpmll_login_path'] ) && trim( $magic_settings['wpmll_login_path'] ) ) {
		        $login_path = ( '/'  === substr( trim( $magic_settings['wpmll_login_path'] ), 0, 1 ) )
                    ? substr_replace( trim( $magic_settings['wpmll_login_path'] ), '', 0, 1 )
                    : trim( $magic_settings['wpmll_login_path'] );

                $full_url = add_query_arg(
                    'wpmll_magic',
                    $data['user_key'],
                    trailingslashit( get_site_url() ) . $login_path
                );
		    } else {
                global $post;
                if ( empty( $post ) ) {
                    $full_url = add_query_arg( 'wpmll_magic', $data['user_key'], wp_login_url() );
                } else {
                    $full_url = add_query_arg( 'wpmll_magic', $data['user_key'], get_permalink( $post->ID ) );
                }
            }
			$status = $this->email_magic_link( $email, $full_url, $magic_settings );

			return array(
				'success' => $status,
				'message' => esc_html__( 'The login link is on it\'s way. Please check your inbox.', 'wp-magic-link-login' ),
			);
		}
	}

	public function email_magic_link( $email, $link, $magic_settings ) {
		if ( trim( $magic_settings['wpmll_email_sender'] ) ) {
			$headers[] = 'From: ' . $magic_settings['wpmll_email_sender'];
		}
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		if ( trim( $magic_settings['wpmll_email_content'] ) ) {
			// check if polylang is active
			if ( is_plugin_active( 'polylang/polylang.php' ) && function_exists( 'pll__' ) ) {
				$content = pll__( $magic_settings['wpmll_email_content'] );
			} elseif ( is_plugin_active( 'polylang-pro/polylang.php' ) && function_exists( 'pll__' ) ) {
				$content = pll__( $magic_settings['wpmll_email_content'] );
			} else {
				$content = $this->process_template_content( $magic_settings['wpmll_email_content'] );
			}
			if ( strpos($content, '{{WPMLL_LINK}}') === false ) {
				$content .= ' {{WPMLL_LINK}}';
			}
			$content = str_replace( 'https://{{WPMLL_LINK}}', $link , $content );
			$content = str_replace( 'http://{{WPMLL_LINK}}', $link , $content );
			$content = str_replace( '{{WPMLL_LINK}}', $link , $content );
		} else {
			$content = esc_html__( 'Hello! You asked for a magic link for an easy login on our website. Here it is: ', 'wp-magic-link-login' );
			$content .= $link;
		}
		if ( trim( $magic_settings['wpmll_email_subject'] ) ) {
			// check if polylang is active
			if ( is_plugin_active( 'polylang/polylang.php' ) && function_exists( 'pll__' ) ) {
				$subject = pll__( $magic_settings['wpmll_email_subject'] );
			} elseif ( is_plugin_active( 'polylang-pro/polylang.php' ) && function_exists( 'pll__' ) ) {
				$subject = pll__( $magic_settings['wpmll_email_subject'] );
			} else {
				$subject = $magic_settings['wpmll_email_subject'];
			}
		} else {
			$subject = esc_html__( 'Magic Login Link you asked for', 'wp-magic-link-login' );
		}

		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$email_sent = wp_mail( $email, $subject, $content, $headers );

		return $email_sent;
	}

	public function check_magic_link_entry_and_invalidate( $wpmll, $magic_hash, $ip = false ) {
		$db = new WpmllDb();
		$db_entry = $db->get_entry_by_hash( $magic_hash );
		if ( ! $db_entry ) {
			return array(
				'success' => false,
				'message' => esc_html__( 'Invalid link', 'wp-magic-link-login' ),
			);
		} else {
			if ( $ip && $db_entry['user_ip'] != $ip && $db_entry['user_ip'] != 'hook_wpmll_generate_login_link' ) {
				return array(
					'success' => false,
					'message' => esc_html__( 'You must login from the same IP', 'wp-magic-link-login' ),
				);
			}
			if ( time() < $db_entry['expire_timestamp'] ) {
				$updated = $db->update_entry( array( 'status' => -1, 'activated_timestamp' => time() ), $db_entry['id'] );
				if ( $updated ) {
					return array(
						'success' => true,
						'email' => $db_entry['user_email'],
						'redirect_to' => $db_entry['redirect_to'],
					);
				} else {
					return array(
						'success' => false,
						'message' => esc_html__( 'An error occured. Please refresh the page or request new link.', 'wp-magic-link-login' ),
					);
				}
			} else {
				return array(
					'success' => false,
					'message' => esc_html__( 'Expired link', 'wp-magic-link-login' ),
				);
			}
		}
	}

	public function process_template_content( $email_content_raw = '' ) {
		$content = convert_chars( convert_smilies( wptexturize( $email_content_raw ) ) );
		if ( isset( $GLOBALS['wp_embed'] ) ) {
			$content = $GLOBALS['wp_embed']->autoembed( $content );
		}
		$content = wpautop( $content );
		$content = do_shortcode( shortcode_unautop( $content ) );

		return $content;
	}

	public function generate_magic_hash( $length = false, $separator = '-' ) {
		if ( ! is_array( $length ) || is_array( $length ) && empty( $length ) ) {
			$length = array( 8, 4, 8, 8, 4, 8 );
		}
		$hash = '';
		foreach ( $length as $key => $string_length ) {
			if ( $key > 0 ) {
				$hash .= $separator;
			}
			$hash .= $this->s4generator( $string_length );
		}

		return $hash;
	}

	public function s4generator( $length ) {
		$token = '';
		$codeAlphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		$max = strlen( $codeAlphabet );
		for ( $i=0; $i < $length; $i++ ) {
			$token .= $codeAlphabet[ $this->crypto_rand_secure( 0, $max-1 ) ];
		}
		return $token;
	}

    public function crypto_rand_secure( $min, $max ) {
		$range = $max - $min;
		if ($range < 1) return $min;
		$log = ceil( log( $range, 2 ) );
		$bytes = (int) ( $log / 8 ) + 1;
		$bits = (int) $log + 1;
		$filter = (int) ( 1 << $bits ) - 1;
		do {
			$rnd = hexdec( bin2hex( openssl_random_pseudo_bytes( $bytes ) ) );
			$rnd = $rnd & $filter;
		} while ( $rnd > $range );
		return $min + $rnd;
	}

}
