<?php
/**
 * Firewall controller
 *
 * @package wpmll
 * @subpackage controllers
 * @since WP Magic Link Login 1.5.7
 */

namespace Wpmll\Controllers;

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

require_once WPMLL_PLUGIN_PATH . 'controllers/class-db.php';
require_once WPMLL_PLUGIN_PATH . 'controllers/class-main.php';

use Wpmll\Controllers\WpmllDb as DbController;
use Wpmll\Controllers\WpmllMain as MainController;

/**
 * Class Firewall
 *
 * @category Controller
 * @package wpmll
 * @author  IV | PIXOLETTE
 * @license  https://pixolette.com
 * @link     https://pixolette.com
 */
class Firewall
{
    public static function get_ip()
    {
        $ip = '';

        if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] )
            && self::check_ip( $_SERVER['HTTP_CLIENT_IP'] )
        ) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }

        if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ips = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
            foreach ( $ips as $i ) {
                if ( self::check_ip( trim( $i ) ) ) {
                    return $i;
                }
            }
        }

        $serverKeys = [
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR',
        ];

        foreach( $serverKeys as $key ) {
            $maybe_ip = ! empty( $_SERVER[ $key ] )
                ? $_SERVER[ $key ]
                : null;

            if ( $maybe_ip !== null
                && self::check_ip( $maybe_ip )
            ) {
                $ip = $maybe_ip;
                break;
            }
        }

        return $ip;
    }

    /**
     * IP-Proxy-Cluster Fix - Validates IP address
     *
     * @param string $ip
     *
     * @return bool
     */
    public static function check_ip( $ip )
    {
        $long = ip2long( $ip );

        if( ! empty( $ip )
            && $long !== -1
            && $long !== false
        ) {
            $privateIps = [
                [ '0.0.0.0', '2.255.255.255' ],
                //[ '10.0.0.0', '10.255.255.255' ],
                [ '127.0.0.0', '127.255.255.255' ],
                [ '169.254.0.0', '169.254.255.255' ],
                [ '172.16.0.0', '172.31.255.255' ],
                [ '192.0.2.0', '192.0.2.255' ],
                [ '192.168.0.0', '192.168.255.255' ],
                [ '255.255.255.0', '255.255.255.255' ],
            ];

            foreach( $privateIps as $r ) {
                $min = ip2long( $r[0] );
                $max = ip2long( $r[1] );

                if( $long >= $min && $long <= $max ) {
                    return false;
                }
            }

            return true;
        }

        return false;
    }

    public static function get_current_url()
    {
        return home_url( $_SERVER['REQUEST_URI'] );
    }

    public static function ban_ip( $ip = null, $period = 24, $url = '' )
    {
        $db_controller = new DbController();
        if ( empty( $ip ) ) {
            $ip = self::get_ip();
        }

        if ( empty( $url ) ) {
            $url = self::get_current_url();
        }

        $args = array(
            'site_id' => get_current_blog_id(),
			'timestamp' => time(),
			'expire_timestamp' => time() + $period * HOUR_IN_SECONDS,
			'user_ip' => $ip,
			'url' => $url,
        );

        $db_controller->firewall_create_entry( $args );
    }

    public static function is_ip_banned()
    {
        if ( is_user_logged_in() ) {
            return false;
        }

        $wpmll_controller = new MainController();
        $settings = $wpmll_controller->get_settings();
        if ( 1 === (int) $settings['firewall_active'] ) {
            $db_controller = new DbController();
            $expire_timestamp = time() - ( $settings['firewall_ban_period'] * HOUR_IN_SECONDS );
            $entries = $db_controller->firewall_get_entries_by_ip( self::get_ip(), $expire_timestamp, $settings['firewall_failures_count'] );
            if ( count( $entries ) >= $settings['firewall_failures_count'] ) {
                $period = ( $entries[0]['timestamp'] - $entries[ count( $entries ) - 1 ]['timestamp'] ) / HOUR_IN_SECONDS;
                if ( $period <= $settings['firewall_failures_count_period'] ) {
                    return true;
                }
            }

            return false;
        }

        return false;
    }
}
